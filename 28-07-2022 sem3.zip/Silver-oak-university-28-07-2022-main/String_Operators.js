let s1 = "Jay";
let s2 = "Suthar";
let s3 = s1 + " " + s2;
document.write(s3);
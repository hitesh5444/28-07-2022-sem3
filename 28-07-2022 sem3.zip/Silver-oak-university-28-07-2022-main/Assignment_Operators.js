var x = 10;
x += 25;

document.write(x);